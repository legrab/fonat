# Implementation deviations

This is a substantial runnable MVP modernized against the Version 4 specification, not a truthful claim that every product requirement is complete.

## Implemented vertical paths

- login, first-run bootstrap endpoint, server sessions, visible logout, cookie invalidation, disabled-user session invalidation;
- stable shell, explicit presentation leave/complete actions, 404 recovery;
- all six guided exercise types with Milkdown Crepe prompt/solution editors and learner preview;
- 24 Grade 8 concepts, 18 authored exercises, five learner fixtures, multiple lessons, evidence, findings, assignments, assessment blueprint, and the complete ten-slide demo sequence;
- live join code, scoped participant token, idempotent answer acceptance, polling, response table, teacher reveal, privacy-safe nickname leaderboard;
- mutable assignment draft, immutable attempts, return/resubmit/accept flow;
- deterministic A/B assessment delivery with copied question snapshots, submission, grading, and grade entry;
- feature-toggled Project route and original Mushroom Yard fixture;
- React/Vite, Fastify, Zod, official MongoDB driver, TanStack Query/Table, React Hook Form, Milkdown Crepe, KaTeX, Mafs, dnd-kit, Playwright configuration;
- Docker, Vercel, Render, OpenAPI generation, package manifests, brand assets, and required documentation set.

## Partial or deferred from the specification

1. **Persistence granularity:** MongoDB stores a bounded optimistic workspace snapshot, not separate aggregate collections with transaction-specific repositories. This is the largest architectural deviation. It preserves end-to-end behavior but is unsuitable for large collections and high concurrency.
2. **Package ZIP staging:** manifests and validation exist, but safe ZIP expansion, MIME checks, staging diff, transactional package update, and round-trip export are not complete.
3. **Revision model:** published exercise revision counters and immutable assessment snapshots exist. Full canonical revision records, scheduled impact notices, package-owned forks, and cross-workflow revision resolution are incomplete.
4. **Blank onboarding UI:** an Admin reset can create a blank workspace, and CRUD surfaces can rebuild it. A dedicated step-by-step onboarding wizard with foundation-package application is incomplete.
5. **Organization depth:** group/course/location creation works through generic guided forms, but historical course roster resolution, explicit inclusion/exclusion, and full timetable recurrence/override editing are simplified.
6. **Assessment sophistication:** deterministic delivery, A/B labels, grading, and grades work. Slot ranking, meaningful equivalent alternatives, shortfall remediation UI, regrade preview, print stylesheet, and five analyzers are incomplete.
7. **Content package volume:** the runtime demo contains the important Grade 8 catalogue. The on-disk packages are contract examples rather than complete exported mirrors of every fixture.
8. **Authorization and CSRF:** role data, protected routes, secure cookie policy, origin checks, and rate limits exist. Fine-grained capabilities and an explicit CSRF token mechanism are incomplete.
9. **Server route decomposition:** feature ownership folders are present, but the Fastify application factory remains large. Extract routes/use cases when a second implementation cycle begins.
10. **Real Mongo and browser verification:** configuration and tests are included. Docker was unavailable in the generation environment. Playwright’s bundled Chromium could not be downloaded because external DNS was unavailable, while the system Chromium is managed with a machine-wide `URLBlocklist: ["*"]`; therefore the browser journey remains unverified here. The production server was instead smoke-tested over HTTP for health, static delivery, login, authenticated Today data, and session cookies.
11. **Localization:** Hungarian UI is the default, with English content fields in package contracts. Full i18next namespaces and complete English UI are not implemented.
12. **Assets:** bundled SVG and external-link records work. Local filesystem rich-media provider and YouTube structured record are only documented foundations.

These deviations favor the specification's priority order: usable navigation, historical delivery snapshots, connected workflows, safe failure, reproducible builds, then extensibility and polish.

## Version 4 toolchain status

The Node.js 24, npm 11, portable-lockfile, production-smoke, dependency-audit, and clean-runtime requirements added in Version 4 are implemented. The application ZIP import/export feature remains incomplete, so no runtime `archiver` dependency is included. See `docs/DEPENDENCY-REVIEW.md` and `docs/VERIFICATION.md`.
